﻿#include "app.hpp"
#include "oglhelper.hpp"

#include <GLFW\glfw3.h>

#include <iostream>
#include <random>

App::App(const unsigned w, const unsigned h) : CgApp(),
	mWindowWidth(w),
	mWindowHeight(h),
	mWindowAspectRatio(w / static_cast<float>(h))
{
}

std::shared_ptr<App> App::create(const unsigned w, const unsigned h)
{
	std::shared_ptr<App> result(new App(w, h));
	result->init();
	return result;
}

void App::init()
{
	mScene = OglHelper::create();

	// storing view & projection matrices in member variables, since you'll need them
	// you're also going to need the viewport matrix, so I suggest creating it here

	mViewMatrix = glm::lookAt(
		glm::vec3(10.f, 10.f, 20.f),
		glm::vec3(0.f, 0.f, 0.f),
		glm::vec3(0.f, 1.f, 0.f));
	mScene->setViewMatrix(mViewMatrix);

	mProjectionMatrix = glm::perspective(glm::radians(45.0f), 1.0f, 0.1f, 100.f);
	mScene->setProjectionMatrix(mProjectionMatrix);

	// generate random spheres

	std::random_device randomDevice;
	std::mt19937 mt(randomDevice());
	std::uniform_real_distribution<float> posDistribution(-5.f, +5.f);
	std::uniform_real_distribution<float> sizeDistribution(0.25f, 0.75f);
	std::uniform_real_distribution<float> hueDistribution(0.f, 1.f);

	mParticles.reserve(50);
	for (unsigned i = 0; i < 50; ++i)
	{
		float x = posDistribution(mt);
		float y = posDistribution(mt);
		float z = posDistribution(mt);

		float s = sizeDistribution(mt);

		// http://lolengine.net/blog/2013/07/27/rgb-to-hsv-in-glsl
		float hue = hueDistribution(mt);
		glm::vec3 p = glm::abs(glm::fract(glm::vec3(hue, hue, hue) + glm::vec3(1, 2 / 3.f, 1 / 3.f)) * 6.f - glm::vec3(3));
		glm::vec3 color = glm::mix(glm::vec3(1), glm::clamp(p - glm::vec3(1), 0.f, 1.f), 0.5f);

		mParticles.push_back( { glm::vec3(x, y, z), s, color });
	}

	mLastFrameTime = std::chrono::high_resolution_clock::now();
}

void App::render()
{
	std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();
	float elapsedSeconds = std::chrono::duration<float>(now - mLastFrameTime).count();
	mTotalElapsedSeconds += elapsedSeconds;
	mLastFrameTime = now;

	mScene->startCurrentFrame(mWindowWidth, mWindowHeight);

	for (auto const& particle : mParticles)
	{
		mScene->drawSphere(glm::translate(glm::mat4(1.f), particle.position)
			* glm::scale(glm::mat4(1.f), glm::vec3(particle.size)), particle.color);
	}

	mScene->endCurrentFrame();
}

void App::cleanup()
{
}

void App::resize(const unsigned w, const unsigned h)
{
	mWindowWidth = w;
	mWindowHeight = h;
	mWindowAspectRatio = mWindowWidth / static_cast<float>(h);
}

void App::mousePosition(const double xpos, const double ypos)
{
	mCurrentMouse = glm::vec2(xpos, mWindowHeight - ypos);
	std::cout << "mouse moved" << std::endl;
	std::cout << "at location " << mCurrentMouse << std::endl;
}

void App::mouseButton(const int button, const int action, const int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
	{
		std::cout << "left mouse pressed" << std::endl;
		std::cout << "at location " << mCurrentMouse << std::endl;
	}
	else if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE)
	{
		std::cout << "left mouse released" << std::endl;
		std::cout << "at location " << mCurrentMouse << std::endl;
	}
}