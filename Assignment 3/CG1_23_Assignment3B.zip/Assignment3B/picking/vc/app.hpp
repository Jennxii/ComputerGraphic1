#pragma once

#include "cg\cg_app.hpp"

#include "cg\glm.hpp"

#include <memory>
#include <chrono>

class OglHelper;

struct Particle
{
	glm::vec3 position;
	float size;
	glm::vec3 color;
};

class App : public cg::CgApp
{

public:

	static std::shared_ptr<App> create(const unsigned w, const unsigned h);

	App(const unsigned w, const unsigned h);

	void init();
	void render();
	void cleanup();
	void resize(const unsigned w, const unsigned h);

	void mousePosition(const double xpos, const double ypos);
	void mouseButton(const int button, const int action, const int mods);

private:

	glm::mat4 mViewMatrix;
	glm::mat4 mProjectionMatrix;

	glm::vec2 mCurrentMouse;

	std::vector<Particle> mParticles;

	// stores beginning of last frame
	std::chrono::steady_clock::time_point mLastFrameTime;
	// elapsed seconds since init was completed
	float mTotalElapsedSeconds = 0.f;

	std::shared_ptr<OglHelper> mScene = nullptr;

	unsigned mWindowWidth;
	unsigned mWindowHeight;
	float mWindowAspectRatio;

};
